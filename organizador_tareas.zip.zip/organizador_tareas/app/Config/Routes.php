<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Home::index');
$routes->get('signup', 'Auth::signup');
$routes->get('login', 'Auth::login');
$routes->get('dashboard', 'Tasks::index');
$routes->post('dashboard/store', 'Tasks::store');