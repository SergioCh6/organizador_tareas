<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Tareas - Organizador</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f9; margin: 0; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; background: white; padding: 15px 20px; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .container { margin-top: 20px; background: white; padding: 25px; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .btn-salir { background: #dc3545; color: white; padding: 8px 15px; text-decoration: none; border-radius: 4px; font-weight: bold; }
        .btn-salir:hover { background: #c82333; }
        input, textarea { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { background: #007bff; color: white; border: none; padding: 10px 15px; border-radius: 4px; cursor: pointer; font-weight: bold; }
        button:hover { background: #0056b3; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #f8f9fa; }
    </style>
</head>
<body>

    <div class="header">
        <h2>Panel Principal - Organizador de Tareas</h2>
        <a href="<?= base_url('/') ?>" class="btn-salir">Cerrar Sesión</a>
    </div>

    <div class="container">
        <h3>Agregar Nueva Tarea Escolar</h3>
        <form action="<?= base_url('dashboard/store') ?>" method="post">
            <input type="text" name="titulo" placeholder="Título de la tarea (ej. Exponer física)" required>
            <textarea name="descripcion" placeholder="Detalles de la tarea..."></textarea>
            <button type="submit">Guardar Tarea</button>
        </form>

        <h3 style="margin-top: 30px;">Mis Tareas Pendientes</h3>
        <table>
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
        <?php if (!empty($tareas)): ?>
            <?php foreach ($tareas as $t): ?>
            <tr>
                <td><?= esc($t['titulo']); ?></td>
                <td><?= esc($t['descripcion']); ?></td>
                <td><?= esc($t['estado']); ?></td>
                <td><span style="color: #28a745; font-weight: bold;">En proceso</span></td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="4" style="text-align: center;">No hay tareas registradas todavía. ¡Agrega una arriba!</td>
            </tr>
        <?php endif; ?>
    </tbody>
        </table>
    </div>

</body>
</html>