<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <style>
        /* Estilos básicos para el formulario de registro */
        body { font-family: Arial, sans-serif; background: #eef2f3; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .caja-registro { background: #ffffff; padding: 35px; border-radius: 6px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 320px; }
        h2 { color: #333; text-align: center; margin-bottom: 20px; }
        .input-form { width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn-enviar { width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 15px; font-weight: bold; margin-top: 10px; }
        .btn-enviar:hover { background: #218838; }
        .link-volver { text-align: center; margin-top: 15px; }
        .link-volver a { color: #007bff; text-decoration: none; }
        .link-volver a:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <div class="caja-registro">
        <h2>Crear Cuenta</h2>
        
        <!-- Formulario de registro de usuarios -->
        <form action="" method="post">
            <label for="username">Usuario:</label>
            <input type="text" id="username" name="username" class="input-form" placeholder="Ingresa tu usuario" required>
            
            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" class="input-form" placeholder="Ingresa tu contraseña" required>
            
            <button type="submit" class="btn-enviar">Registrarse</button>
        </form>

        <div class="link-volver">
            <p><a href="<?= base_url('/') ?>">Regresar al inicio</a></p>
        </div>
    </div>

</body>
</html>