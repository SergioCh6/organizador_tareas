<?php

namespace App\Controllers;

class Tasks extends BaseController
{
    public function index()
    {
        // Conectamos con la base de datos usando el modelo por defecto o consulta directa
        $db = \Config\Database::connect();
        $builder = $db->table('tasks');
        
        // Obtenemos todas las tareas guardadas
        $data['tareas'] = $builder->get()->getResultArray();

        // Cargamos la vista del dashboard enviándole las tareas
        return view('tasks/dashboard', $data);
    }

    public function store()
    {
        // Recibimos los datos enviados desde el formulario
        $titulo = $this->request->getPost('titulo');
        $descripcion = $this->request->getPost('descripcion');

        // Insertamos la tarea en la base de datos
        $db = \Config\Database::connect();
        $builder = $db->table('tasks');
        
        $builder->insert([
            'titulo' => $titulo,
            'descripcion' => $descripcion,
            'estado' => 'Pendiente',
            'created_at' => date('Y-m-d H:i:s')
        ]);

        // Redirigimos de vuelta al dashboard para ver la lista actualizada
        return redirect()->to(base_url('dashboard'));
    }
}
