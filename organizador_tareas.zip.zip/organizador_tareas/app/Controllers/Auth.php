<?php

namespace App\Controllers;

// Controlador principal para manejar el acceso de usuarios
class Auth extends BaseController
{
    // Muestra la vista del formulario de registro
    public function signup()
    {
        // TODO: Agregar validación de datos del formulario más adelante
        return view('auth/signup');
    }

    // Muestra la vista del formulario de inicio de sesión
    public function login()
    {
        // Aquí validaremos la sesión del usuario con la base de datos
        return view('auth/login');
    }
}